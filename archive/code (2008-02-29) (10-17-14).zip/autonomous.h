/*******************************************************************************
* FILE NAME: autonomous.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2008 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
*******************************************************************************/

#ifndef _autonomous_h
#define _autonomous_h

// Defines for different autonomous modes
#define CIRCLE_FIELD    1
#define GET_BALL        2

#define POSITION_1  0
#define POSITION_2  1
#define POSITION_3  2

// Define the states for CIRCLE_FIELD
#define CIRCLE_FIELD_FIND_WALL              0
#define CIRCLE_FIELD_FOLLOW_WALL_ONE        1
//#define CIRCLE_FIELD_CONTINUE               2
//#define CIRCLE_FIELD_FOLLOW_WALL_TWO        3
#define CIRCLE_FIELD_TURN_LEFT_ONE          4
#define CIRCLE_FIELD_DRIVE_STRAIGHT         5
#define CIRCLE_FIELD_TURN_LEFT_TWO          6
#define CIRCLE_FIELD_TURN_LEFT              7

// Define the constants for CIRCLE_FIELD
#define CIRCLE_FIELD_FORWARD_SPEED          40
#define CIRCLE_FIELD_DISTANCE_HUG           1000   // increases as it gets closer
#define CIRCLE_FIELD_DISTANCE_NOWALL        50
#define CIRCLE_FIELD_Z_GAIN                 7.0
#define CIRCLE_FIELD_Z_LIMIT                20
#define CIRCLE_FIELD_TURN_LEFT_SPEED        (-1*40)

// Define the constants for GET_BALL
#define GET_BALL_IDENTIFY_BALL      1
#define GET_BALL_RAISE_TOWER        2
#define GET_BALL_DRIVE_FORWARD      3

#define IR_CLOSE_VALUE 1000
// function prototypes
void Autonomous_Init(void);
void Autonomous(void);
void Autonomous_Spin(void);

int Get_Auto_Mode(void);
int Get_Starting_Position(void);
void MORT_Autonomous_Mode(int mode);
void Circle_Field(void);
void Circle_Field_2(void);
void Get_Ball(void);

void Robocoach_Override(void);

void Delay(unsigned int);

#endif
