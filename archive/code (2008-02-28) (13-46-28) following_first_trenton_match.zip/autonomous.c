/*******************************************************************************
*
*	TITLE:		autonomous.c
*
*	VERSION:	0.1 (Beta)
*
*	DATE:		31-Dec-2007
*
*	AUTHOR:		R. Kevin Watson
*				kevinw@jpl.nasa.gov
*
*	COMMENTS:	This file best viewed with tabs set to four.
*
*				You are free to use this source code for any non-commercial
*				use. Please do not make copies of this source code, modified
*				or un-modified, publicly available on the internet or elsewhere
*				without permission. Thanks.
*
*				Copyright �2007-2008 R. Kevin Watson. All rights are reserved.
*
********************************************************************************
*
*	Change log:
*
*	DATE         REV  DESCRIPTION
*	-----------  ---  ----------------------------------------------------------
*	31-Dec-2007  0.1  RKW Original
*
*******************************************************************************/
#include "ifi_frc.h"
#include "timers.h"
#include "interrupts.h"
#include "encoder.h"
#include "serial_ports.h"
#include "ifi_code.h"
#include "autonomous.h"
#include "camera.h"
#include "tracking.h"
#include "mort_defines.h"
#include "adc.h"
#include "gyro.h"
#include "camera.h"
#include  "tracking.h"

unsigned int range_left_front = 0;
unsigned int range_left_back = 0;
unsigned int range_front_left = 0;
unsigned int range_front_right = 0;

int range_error_front = 0;
int range_error_back = 0;
int range_error_difference = 0;

unsigned char ir_debounce = 0;

long angle = 0;

extern unsigned char height_flag;

unsigned char manual_override = FALSE;

unsigned char auto_state = CIRCLE_FIELD_FIND_WALL;


int Get_Auto_Mode(void)
{
    if (rc_dig_in10)        // red 1
        return 1;
    else if (rc_dig_in11)   // red 2
        return 2;
    else if (rc_dig_in12)   // blue 1
        return 3;
    else if (rc_dig_in13)   // blue 2
        return 4;
    else
        return -1;

}

int Get_Starting_Position(void)
{
    return POSITION_1;
}

void Autonomous_Init(void)
{
    printf("Starting timer\r\n");
    Timer_2_Start();
    Stop_Gyro_Bias_Calc();
    Reset_Gyro_Angle();
    manual_override = FALSE;
    height_flag = HEIGHT_FLAG_MANUAL;
}

void Autonomous(void)
{
    int mode = -1;

    Camera_Handler();
    Service_Brakes(1);

    Robocoach_Override();

    mode = Get_Auto_Mode();

    printf("mode: %d \r\n", mode);

    if (mode == 1 || mode == 3)
        Circle_Field();
    else if (mode == 2 || mode == 4)
        Reset_Outputs();
    else
        Reset_Outputs();

    Service_Dashboard_Data();
}

void Autonomous_Spin(void)
{

    range_left_front = Get_ADC_Result(IR_LEFT_FRONT);
    range_left_back = Get_ADC_Result(IR_LEFT_BACK);
    range_front_left = Get_ADC_Result(IR_FRONT_LEFT);
    range_front_right = Get_ADC_Result(IR_FRONT_RIGHT);
    range_error_front = CIRCLE_FIELD_DISTANCE_HUG - range_left_front;
    range_error_back = CIRCLE_FIELD_DISTANCE_HUG - range_left_back;
    range_error_difference = (range_error_front - range_error_back) * -1;   // when positive, you need to turn left

    Process_Gyro_Data(TRUE);

    angle = Get_Gyro_Angle();
}

void Circle_Field( void )
{
    //static unsigned char auto_state = CIRCLE_FIELD_FIND_WALL;

    int x = 0;
    int y = 0;
    int z = 0;
    unsigned int time = 0;
    static unsigned char ir_debounce = 0;

    time = Timer_2_Get_Time();

    printf("Time: %3d Gyro: %4ld rlf:%3d  rlb:%3d   rfl:%3d    rfr:%3d  state:%d\r\n",time, Get_Gyro_Angle(), range_left_front, range_left_back, range_front_left, range_front_right, auto_state);

    switch (auto_state)
    {
        case CIRCLE_FIELD_FIND_WALL:

            y = CIRCLE_FIELD_FORWARD_SPEED;
            z = 0;

            if ((range_left_front > CIRCLE_FIELD_DISTANCE_NOWALL && range_left_back > CIRCLE_FIELD_DISTANCE_NOWALL))
            {
                ir_debounce++;
            }
            else
            {
                ir_debounce = 0;
            }

            if (ir_debounce >= 3)
            {
                auto_state = CIRCLE_FIELD_FOLLOW_WALL;
                ir_debounce = 0;
            }
            height_flag = HEIGHT_FLAG_LOW;
            Service_Tower();

            break;

        case CIRCLE_FIELD_FOLLOW_WALL:

            y = CIRCLE_FIELD_FORWARD_SPEED;
            z = (range_error_difference / CIRCLE_FIELD_Z_GAIN);
            z = Limit(z, -1*CIRCLE_FIELD_Z_LIMIT, CIRCLE_FIELD_Z_LIMIT);

            if (range_left_front < CIRCLE_FIELD_DISTANCE_NOWALL)
            {
                Reset_Gyro_Angle();
                y = CIRCLE_FIELD_FORWARD_SPEED;
                z = CIRCLE_FIELD_TURN_LEFT_SPEED;
                auto_state = CIRCLE_FIELD_TURN_LEFT_ONE;
                ir_debounce = 0;
            }
            Get_Ball();

            break;

        case CIRCLE_FIELD_TURN_LEFT_ONE:

            y = 0;//CIRCLE_FIELD_FORWARD_SPEED;
            z = CIRCLE_FIELD_TURN_LEFT_SPEED;

            if (angle < -530)
            {
                z = 0;
                auto_state = CIRCLE_FIELD_DRIVE_STRAIGHT;
                Timer_2_Reset();
            }

            break;

        case CIRCLE_FIELD_DRIVE_STRAIGHT:

            y = CIRCLE_FIELD_FORWARD_SPEED;
            z = 0;

            if (time > 1000)
            {
                auto_state = CIRCLE_FIELD_TURN_LEFT_TWO;
                Timer_2_Reset();
                Reset_Gyro_Angle();
            }

            break;

        case CIRCLE_FIELD_TURN_LEFT_TWO:

            y = 0;
            z = CIRCLE_FIELD_TURN_LEFT_SPEED;

            if (angle < -530)
            {
                z = 0;
                auto_state = CIRCLE_FIELD_FIND_WALL;
            }

            break;

        default:

            break;

    }

    Mec_Drive(x, y, z);
}

void Get_Ball(void)
{
    static char auto_state = GET_BALL_IDENTIFY_BALL;
    static unsigned int old_camera_t_packets = 0;

    if(camera_t_packets != old_camera_t_packets) //if all is good with the camera
    {
        old_camera_t_packets = camera_t_packets; //update so we know next time if the camera is working

        if(T_Packet_Data.confidence >= CONFIDENCE_THRESHOLD_DEFAULT)
        {
            if((T_Packet_Data.mx-PAN_TARGET_PIXEL_DEFAULT) < 10 || (T_Packet_Data.mx-PAN_TARGET_PIXEL_DEFAULT) > -1*10)
            {
                    height_flag = HEIGHT_FLAG_MIDDLE;
                    Service_Tower();
            }
        }
    }
//    printf("Offset:%d \r\n", ((int)T_Packet_Data.mx - PAN_TARGET_PIXEL_DEFAULT));
}

void Robocoach_Override(void)
{

    static int timeflag1;
    int x = 0;
    int y = 0;
    int z = 0;

    timeflag1= Timer_2_Get_Time();

    Service_Tower();

    if(ROBOCOACH_1)
    {
        x=0;
        y=0;
        z=0;
        height_flag=HEIGHT_FLAG_LOW;
        manual_override = TRUE;
    }
    else if (ROBOCOACH_2)
    {

        x=0;
        y=127;
        z=0;
//        Delay(100);
    }
    else if (ROBOCOACH_3)
    {
        x=0;
        y=-127;
        z=0;
    }
    else if (ROBOCOACH_4)
    {
        x=-127;
        y=0;
        z=0;
    }
    Mec_Drive(x,y,z);
}

void Delay(unsigned int ms)
{
    Timer_2_Reset();
    Timer_2_Start();
//  while ((ms == 0 || Timer_2_Get_Time() <= ms) && !ROBOCOACH_2)
    while (Timer_2_Get_Time() <= ms)
    {
        Getdata(&rxdata);
        if (statusflag.NEW_SPI_DATA)
        {
            Reset_Outputs();
            statusflag.NEW_SPI_DATA = 0;
        }
        Putdata(&txdata);
    }
    Timer_2_Stop();
}


