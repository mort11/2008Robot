/*******************************************************************************
*
*	TITLE:		autonomous.c
*
*	VERSION:	0.1 (Beta)
*
*	DATE:		31-Dec-2007
*
*	AUTHOR:		R. Kevin Watson
*				kevinw@jpl.nasa.gov
*
*	COMMENTS:	This file best viewed with tabs set to four.
*
*				You are free to use this source code for any non-commercial
*				use. Please do not make copies of this source code, modified
*				or un-modified, publicly available on the internet or elsewhere
*				without permission. Thanks.
*
*				Copyright �2007-2008 R. Kevin Watson. All rights are reserved.
*
********************************************************************************
*
*	Change log:
*
*	DATE         REV  DESCRIPTION
*	-----------  ---  ----------------------------------------------------------
*	31-Dec-2007  0.1  RKW Original
*
*******************************************************************************/
#include "ifi_frc.h"
#include "timers.h"
#include "interrupts.h"
#include "encoder.h"
#include "serial_ports.h"
#include "ifi_code.h"
#include "autonomous.h"
#include "camera.h"
#include "tracking.h"
#include "mort_defines.h"
#include "adc.h"
#include "gyro.h"
#include "camera.h"
#include  "tracking.h"

int x = 0;
int y = 0;
int z = 0;

extern unsigned char height_flag;

unsigned char auto_state = 0;

int Get_Auto_Mode(void)
{
    if (rc_dig_in10 == 0)        // red 1
    {
        return 1;
    }
    else if (rc_dig_in11 == 0)   // red 2
    {
        return 2;
    }
    else if (rc_dig_in12 == 0)   // blue 1
    {
        return 3;
    }
    else if (rc_dig_in13 == 0)   // blue 2
    {
            return 4;
    }
    else
    {
            return -1;
    }
}

void Autonomous_Init(void)
{
    height_flag = HEIGHT_FLAG_MANUAL;
}

void Autonomous(void)
{
    int mode = -1;

    Camera_Handler();
    Service_Brakes(1);

    mode = Get_Auto_Mode();

    if (mode == 1)
        IR_Drive();
    else if (mode == 2)
        Track_Ball();
    else if (mode == 3 || mode == 4)
        Reset_Outputs();
    else
        Reset_Outputs();

    Service_Tower();
    Mec_Drive(x,y,z);
    Service_Dashboard_Data();
}

void Autonomous_Spin(void)
{
    Timer_2_Start();

}

void IR_Drive(void)
{

    printf("%d  %d  %d  %d \r\n",ROBOCOACH_1,ROBOCOACH_2,ROBOCOACH_3,ROBOCOACH_4);
    if(ROBOCOACH_1)
    {
        x=0;
        y=0;
        z=-70;
        Timer_2_Reset();
    }
    else if (ROBOCOACH_2)
    {
        x=0;
        y=110;
        z=0;
        Timer_2_Reset();
    }
    else if (ROBOCOACH_3)
    {
        x=0;
        y=0;
        z=70;
        Timer_2_Reset();
    }
    else if (ROBOCOACH_4 && Timer_2_Get_Time() > 100)
    {
        if (( height_flag == HEIGHT_FLAG_MANUAL || height_flag == HEIGHT_FLAG_LOW) && Get_Encoder_1_Count() == 0)
        {
            height_flag = HEIGHT_FLAG_MIDDLE;
        }
        else
        {
            height_flag = HEIGHT_FLAG_LOW;
        }
        Timer_2_Reset();
    }
    else if ( Timer_2_Get_Time() >= 200)
    {
        x=0;
        y=0;
        z=0;
    }
}
