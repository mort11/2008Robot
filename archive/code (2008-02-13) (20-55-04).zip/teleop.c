/*******************************************************************************
*
*	TITLE:		teleop.c
*
*	VERSION:	0.1 (Beta)
*
*	DATE:		31-Dec-2007
*
*	AUTHOR:		R. Kevin Watson
*				kevinw@jpl.nasa.gov
*
*	COMMENTS:	This file best viewed with tabs set to four.
*
*				You are free to use this source code for any non-commercial
*				use. Please do not make copies of this source code, modified
*				or un-modified, publicly available on the internet or elsewhere
*				without permission. Thanks.
*
*				Copyright �2007-2008 R. Kevin Watson. All rights are reserved.
*
********************************************************************************
*
*	Change log:
*
*	DATE         REV  DESCRIPTION
*	-----------  ---  ----------------------------------------------------------
*	31-Dec-2007  0.1  RKW Original
*
*******************************************************************************/

#include <adc.h>
#include "ifi_frc.h"
#include "timers.h"
#include "interrupts.h"
#include "encoder.h"
#include "serial_ports.h"
#include "ifi_code.h"
#include "teleop.h"
#include "camera.h"
#include "tracking.h"
#include "mort_defines.h"
#include "adc.h"

unsigned char height_flag = HEIGHT_FLAG_MANUAL;
unsigned char tower_at_target = FALSE;

int drive_x = 0;
int drive_y = 0;
int drive_z = 0;
int tower_joystick = 0;

// CALLED ONCE
void Teleop_Init(void)
{
    height_flag = HEIGHT_FLAG_MANUAL;
    tower_at_target = FALSE;
}

// CALLED WHEN DRIVING ROBOT
void Teleop(void)
{
    unsigned int range = 1;

    Service_Joysticks();
    Service_Height_Flags_2();
    Service_Tower();
    Service_Leds();
    Service_Brakes(DRIVE_TRIG);
    Mec_Drive(drive_x, drive_y, drive_z);
/*
    //printf("heightflag: %d\r\n", height_flag);
    range = Get_ADC_Result(1);
    printf("%d  ", range);
    range = Get_ADC_Result(2);
    printf("%d \r\n", range);
*/
    Service_Program_Button();
    Service_Dashboard_Data();
}

// CALLED BETWEEN MASTER DATA
void Teleop_Spin(void)
{
}

void Service_Program_Button(void)
{
    int byte_count = 0;
    int i = 0;

    byte_count = Serial_Port_One_Byte_Count();
    if (byte_count > 0)
    {
        for (i=0; i<byte_count; i++)
        {
            if (Read_Serial_Port_One() == 'p')
            {
                PROGRAM_BUTTON = 0;
            }
        }
    }

}

void Mec_Drive(int x, int y, int z)
{
    /**
    Objective
        Controls the motor outputs on 4 mecanum wheels using a 3 axis joystick input

    Called By
        ??

    Parameters
        int x : Strafing Direction (-127,127)
        int y : Forward and Reverse (-127,127)
        int z : Spin Direction (-127,127)

    Notes
        Based upon the CheifDelphi white paper for initial determination of wheel speeds,
        then scales them based upon a reduction value (a double).
    **/

	int left_front = 0;
	int left_back = 0;
	int right_front = 0;
	int right_back = 0;
    double reduction;

	right_front=y-x-z;
	left_front=y+x+z;
	right_back=y+x-z;
	left_back=y-x+z;

    // Using the reduction variable here to avoid movre variables.
    // Finds the absolute maximum value of the 4 wheel speeds
	reduction = absmax( absmax(right_front,right_back) , absmax(left_front, left_back) );

	// Determine the multiple to decrease the motor values by
	if (reduction > 127.0)
	{
		reduction /= 127.0;
	}
	else if (reduction < -127.0)
	{
	    //
		reduction /= -127.0;
	}
	else
	{
	    // If we are within the range, no reduction
		reduction = 1;
	}

    //Reduce the motor values so that the max is at 127 or min at -127
	left_front /= reduction;
	left_back /= reduction;
	right_back /= reduction;
	right_front /= reduction;

    // Make the value range from 0 to 255, with 128 and 127 of the converted value being equal
	left_front 	+= 127;
	left_back 	+= 127;
	right_front += 127;
	right_back 	+= 127;

    left_front = Limit(left_front, 0, 255);
    left_back = Limit(left_back, 0, 255);
    right_front = Limit(right_front, 0, 255);
    right_back = Limit(right_back, 0, 255);

	// CHANGE TO DEFINES FOR PWMS
	left_front = 255 - left_front;
	left_back = 255 - left_back;

	// Scale to overcome victor deadzone
	if (left_front > 128)
	{
	    left_front = (((127.0 - PWM_DEADZONE_LEFT) / 127.0) * (left_front-127.0)) + PWM_DEADZONE_LEFT + 127.0;
	}

    if (left_back > 128)
	{
	    left_back = (((127.0 - PWM_DEADZONE_LEFT) / 127.0) * (left_back-127.0)) + PWM_DEADZONE_LEFT + 127.0;
	}

    if (right_front > 127)
	{
	    right_front = (((127.0 - PWM_DEADZONE_RIGHT) / 127.0) * (right_front-127.0)) + PWM_DEADZONE_RIGHT + 127.0;
	}

    if (right_back > 127)
	{
	    right_back = (((127.0 - PWM_DEADZONE_RIGHT) / 127.0) * (right_back-127.0)) + PWM_DEADZONE_RIGHT + 127.0;
	}


    left_front = Limit(left_front, 0, 255);
    left_back = Limit(left_back, 0, 255);
    right_front = Limit(right_front, 0, 255);
    right_back = Limit(right_back, 0, 255);

    BACK_LEFT 	= left_back;
    FRONT_LEFT  = left_front;
	FRONT_RIGHT = right_front;
	BACK_RIGHT 	= right_back;
}

void Service_Joysticks(void)
{
    // Makes copies
    drive_x = DRIVE_X;
    drive_y = DRIVE_Y;
    drive_z = DRIVE_Z;
    tower_joystick = TOWER_JOYSTICK;

    // Translate to zero (center)
    drive_x -= DRIVE_X_OFFSET;
    drive_y -= DRIVE_Y_OFFSET;
    drive_z -= DRIVE_Z_OFFSET;
    tower_joystick -= TOWER_JOYSTICK_OFFSET;

    // Scales inputs to -127  127
    if (drive_x > 0)
    {
        drive_x = (127.0 / DRIVE_X_MAX) *  drive_x;
    }
    else if (drive_x < 0)
    {
        drive_x = ((-1.0 * 127.0) / DRIVE_X_MIN) * drive_x;
    }

    if (drive_y > 0)
    {
        drive_y = (127.0 / DRIVE_Y_MAX) *  drive_y;
    }
    else if (drive_y < 0)
    {
        drive_y = ((-1.0 * 127.0) / DRIVE_Y_MIN) * drive_y;
    }

    if (drive_z > 0)
    {
        drive_z = (127.0 / DRIVE_Z_MAX) *  drive_z;
    }
    else if (drive_z < 0)
    {
        drive_z = ((-1.0 * 127.0) / DRIVE_Z_MIN) * drive_z;
    }

    if (tower_joystick > 0)
    {
        tower_joystick = (127.0 / TOWER_JOYSTICK_MAX) * tower_joystick;
    }
    else if (tower_joystick < 0)
    {
        tower_joystick = ((-1.0 * 127.0) / TOWER_JOYSTICK_MIN) * tower_joystick;
    }

    // Puts deadband on all joysticks
    drive_x = Deadband(drive_x, DRIVE_X_DEADBAND);
    drive_y = Deadband(drive_y, DRIVE_Y_DEADBAND);
    drive_z = Deadband(drive_z, DRIVE_Z_DEADBAND);
    tower_joystick = Deadband(tower_joystick, TOWER_JOYSTICK_DEADBAND);

    drive_x *= -1;
    drive_y *= 1;
    drive_z *= -1;
    tower_joystick *= -1;

    drive_x = Limit(drive_x, -127, 127);
    drive_y = Limit(drive_y, -127, 127);
    drive_z = Limit(drive_z, -127, 127);
    tower_joystick = Limit(tower_joystick, -127, 127);

   // printf("Actual x:%3d   y:%3d   z:%3d  t:%3d   Adjust x:%3d   y:%3d   z:%3d   t:%3d   \r\n", DRIVE_X, DRIVE_Y, DRIVE_Z, TOWER_JOYSTICK, drive_x, drive_y, drive_z, tower_joystick);
}

void Service_Height_Flags (void)
{
	/*
		Press a button (you han hold it), it goes to that height
		Press button again (you can hold it) while arm is not at target, it cancels selection
		Note:
			What happens if arm is at target, do you have to press the button twice,
			first to cancle and second to go to next height?
	*/

	unsigned char button_pressed = 0;
	static unsigned char button_old = 0;
	static unsigned char cancel = 1;

    if (TOWER_BUTTON_LOW)
    {
        height_flag = HEIGHT_FLAG_LOW;
		button_pressed = 1;
    }
    else if (TOWER_BUTTON_MIDDLE)
    {
        height_flag = HEIGHT_FLAG_MIDDLE;
		button_pressed = 1;
    }
    else if (TOWER_BUTTON_HIGH)
    {
        height_flag = HEIGHT_FLAG_HIGH;
		button_pressed = 1;
    }

	if (button_pressed && button_old == 0)
	{
		cancel = !cancel;
	}
	button_old = button_pressed;

	if (cancel && !tower_at_target)
	{
		height_flag = HEIGHT_FLAG_MANUAL;	// over-ride height flag with manual
		cancel = 1;
	}

}

void Service_Height_Flags_2 (void)
{
	unsigned char button_pressed = 0;
	static unsigned char button_cancel = 0;
	static unsigned char button_released = 0;

	button_pressed = TOWER_BUTTON_LOW + TOWER_BUTTON_MIDDLE + TOWER_BUTTON_HIGH;
	button_pressed = Limit(button_pressed, 0, 1); //retard check

	if (TOWER_BUTTON_LOW && !button_cancel)
    {
        height_flag = HEIGHT_FLAG_LOW;
    }
    else if (TOWER_BUTTON_MIDDLE && !button_cancel)
    {
        height_flag = HEIGHT_FLAG_MIDDLE;
    }
    else if (TOWER_BUTTON_HIGH && !button_cancel)
    {
        height_flag = HEIGHT_FLAG_HIGH;
    }

	if (height_flag != HEIGHT_FLAG_MANUAL && !button_pressed)
	{
		button_released = 1;
	}

	if (button_pressed && button_released)
	{
		height_flag = HEIGHT_FLAG_MANUAL;
		button_released = 0;
		button_cancel = 1;
	}
	else if (!button_pressed && !button_released)
	{
        button_cancel = 0;
	}
}

/**
inputs :
    TOWER_BUTTON_HIGH
    TOWER_BUTTON_MIDDLE
    TOWER_BUTTON_LOW
outputs :
    height_flag = ( HEIGHT_FLAG_HIGH, HEIGHT_FLAG_MIDDLE, HEIGHT_FLAG_LOW, HEIGHT_FLAG_MANUAL )
**/
void Service_Height_Flags_noob ( void )
{
    static char button_up = 1;

	if (!(TOWER_BUTTON_HIGH || TOWER_BUTTON_MIDDLE || TOWER_BUTTON_LOW ))
    {
        button_up = 1;
    }
    else if (button_up && (height_flag ==  HEIGHT_FLAG_HIGH * TOWER_BUTTON_HIGH + HEIGHT_FLAG_MIDDLE * TOWER_BUTTON_MIDDLE + HEIGHT_FLAG_LOW * TOWER_BUTTON_LOW))
	{
		height_flag = HEIGHT_FLAG_MANUAL;
		button_up = 0;
	}
    else if ( button_up && (TOWER_BUTTON_HIGH ^ TOWER_BUTTON_MIDDLE ^ TOWER_BUTTON_LOW ^ 0 ))
    {
		height_flag = HEIGHT_FLAG_HIGH   * TOWER_BUTTON_HIGH
                    + HEIGHT_FLAG_MIDDLE * TOWER_BUTTON_MIDDLE
                    + HEIGHT_FLAG_LOW    * TOWER_BUTTON_LOW;
		button_up = 0;
	}

}


void Service_Tower(void)
{
    static int set_height = 0;       // Desired height variable

	int encoder_count = 0;
	int encoder_error = 0;

	int temp_tower = 0;              // temp value for tower speed
	int temp_rollers = 0;             // temp value for roller speed

	TOWER_BUTTON_ROLLERS = !TOWER_BUTTON_ROLLERS; //reverse the button which is normally 1

    encoder_count = Get_Encoder_1_Count();
    tower_at_target = 0;

    if (height_flag == HEIGHT_FLAG_MANUAL)        // If we are in manual mode
    {
        if (TOWER_BUTTON_ROLLERS == 1)
        {
            temp_rollers = tower_joystick;
            temp_tower = 0;
        }
        else
        {
            temp_rollers = 0;
            temp_tower = tower_joystick;

            if (encoder_count >= TOWER_ENCODER_LIMIT && temp_tower > 0)
            {
                 temp_tower = 0;
            }
        }
    }
    else
    {
        switch (height_flag)
        {
            case HEIGHT_FLAG_HIGH:

                set_height = HEIGHT_COUNT_HIGH;

                break;

            case HEIGHT_FLAG_MIDDLE:

                set_height = HEIGHT_COUNT_MIDDLE;

                break;

            case HEIGHT_FLAG_LOW:

                set_height = HEIGHT_COUNT_LOW;

                break;
        }

        encoder_error = set_height - encoder_count;
        temp_tower = encoder_error * TOWER_GAIN;

        if (encoder_error <= TOWER_ENCODER_DEADZONE && encoder_error >= (-1 * TOWER_ENCODER_DEADZONE))  // If the arm is in the deadzone
        {
            temp_tower = 0;
            tower_at_target = 1;
            height_flag = HEIGHT_FLAG_MANUAL;
        }

        if (TOWER_BUTTON_ROLLERS == 1)
        {
            temp_rollers = tower_joystick;
        }
        else
        {
            temp_rollers = 0;
        }
    }

	temp_tower = Limit(temp_tower, -127, 127);
	temp_rollers = Limit(temp_rollers, -127, 127);

	TOWER_MOTOR = temp_tower + 127;
	ROLLER_MOTOR = temp_rollers + 127;
}

int Deadband(int value, int band)
{
    /**
    Objective
        Scale an inputed value between a range "A" while a range "D"
        at the center of the range "A" scales to 0.

    Parameters
        int value : The value to be scaled based upon the "dead" zone.
        int band  : The side length of the "dead" range.

    Return
        int : The scaled value
    **/

	if (value <= (band/2.0) && value >= (-band/2.0))
	{
		return 0;
	}
	else if (value > 0)
	{
		return (127* (value - band/2.0) /(127 - band/2.0));
	}
	else
	{
		return (127* (value + band/2.0) /(127 - band/2.0));
	}
}

int Limit (int num, int low, int high)
{
    /**
    Objective
        Prevent a value from exceeding a specified range by setting it the max or min of the range if
        it falls below the range or rests above the range.

    Parameters
        int num : The number to be forced within the range
        int low : The bottom of the range (<high)
        int high: The top of the range (>low)

    Return
        int : num if the value falls bettween low and high, otherwise low or high
    **/

	if (num > high)
		return high;
	else if (num < low)
		return low;

	return num;
}

int absmax(int n1,int n2)
{
    /**
    Objective
        Determines the input value that has a greater absolute value and returns it.

    Called By
        outputs.c/Mec_Drive_2

    Parameters
        int n1 : An integer to compare
        int n2 : An integer to compare

    Return
        The intiger which has a greater absolute value
    **/

	if(abs(n1) > abs(n2))
		return n1;
	else
		return n2;

}

int abs(int n)
{
    /**
    Objective
        Returns the absolute value of the parameter.

    Called By
        outputs.c/Mec_Drive_2

    Parameters
        int n : value to determine absolute value of.

    Retrun
        The absolute value of n.
    **/

	if (n < 0)
		return -n;
	else
		return  n;
}

void Service_Brakes(unsigned char onoff)
{
    BRAKE_1 = !onoff;
    BRAKE_2 = !onoff;
    BRAKE_3 = !onoff;
    BRAKE_4 = !onoff;
}

void Service_Leds(void)
{
    switch (height_flag)
    {
        case HEIGHT_FLAG_LOW:

            HEIGHT_LED_HIGH = 0;
            HEIGHT_LED_MIDDLE = 0;
            HEIGHT_LED_LOW = 1;

            break;

        case HEIGHT_FLAG_MIDDLE:

            HEIGHT_LED_HIGH = 0;
            HEIGHT_LED_MIDDLE = 1;
            HEIGHT_LED_LOW = 0;

            break;

        case HEIGHT_FLAG_HIGH:

            HEIGHT_LED_HIGH = 1;
            HEIGHT_LED_MIDDLE = 0;
            HEIGHT_LED_LOW = 0;

            break;

        case HEIGHT_FLAG_MANUAL:

            HEIGHT_LED_HIGH = 0;
            HEIGHT_LED_MIDDLE = 0;
            HEIGHT_LED_LOW = 0;

            break;

        default:

            HEIGHT_LED_HIGH = 0;
            HEIGHT_LED_MIDDLE = 0;
            HEIGHT_LED_LOW = 0;

            break;
    }
}

/**
Outputs :
    User_Byte{1-6}
**/
void Service_Dashboard_Data( void )
{
    static unsigned char p_num = 0;
    User_Byte1 = p_num;
    if (p_num == 0)
    {
        User_Byte2 = DRIVE_X;      // Joystick X
        User_Byte3 = DRIVE_Y;      // Joystick Y
        User_Byte4 = DRIVE_Z;    // Joystick Z
        User_Byte5 = TOWER_JOYSTICK;      // Throttle
        User_Byte6 = Get_Encoder_1_Count(); // Encoder 1
    }
    else if (p_num == 1)
    {
        User_Byte2 = TOWER_BUTTON_HIGH<<8 | TOWER_BUTTON_MIDDLE<<7 | TOWER_BUTTON_LOW<<6
                   | TOWER_BUTTON_ROLLERS<<5 | HEIGHT_LED_HIGH<<4 | HEIGHT_LED_MIDDLE<<3
                   | HEIGHT_LED_LOW<<2 | TOWER_BALL_SWITCH<<1 | 0;
        User_Byte3 = Get_ADC_Result(IR_LEFT_FRONT);
        User_Byte4 = Get_ADC_Result(IR_LEFT_BACK);
        User_Byte5 = 0;
        User_Byte6 = 0;

    }

    if(p_num < NUM_PACKETS - 1)
    {
        p_num ++;
    }
    else
    {
        p_num = 0;
    }
}
