/*******************************************************************************
* FILE NAME: autonomous.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2008 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
*******************************************************************************/

#ifndef _autonomous_h
#define _autonomous_h

// Defines for different autonomous modes
#define CIRCLE_FIELD    1
#define TRACK_BALL      2

// Define the states for CIRCLE_FIELD
#define CIRCLE_FIELD_FIND_WALL          0
#define CIRCLE_FIELD_FOLLOW_WALL        1
#define CIRCLE_FIELD_TURN_LEFT          2

// Define the constants for CIRCLE_FIELD
#define CIRCLE_FIELD_FORWARD_SPEED          40
#define CIRCLE_FIELD_DISTANCE_HUG           1000   // increases as it gets closer
#define CIRCLE_FIELD_DISTANCE_NOWALL        50
#define CIRCLE_FIELD_Z_GAIN                 7.0
#define CIRCLE_FIELD_Z_LIMIT                20
#define CIRCLE_FIELD_TURN_LEFT_SPEED        (-1*40)

// function prototypes
void Autonomous_Init(void);
void Autonomous(void);
void Autonomous_Spin(void);

int Get_Auto_Mode(void);
void MORT_Autonomous_Mode(int mode);
void Circle_Field( void );

#endif
