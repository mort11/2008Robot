/*******************************************************************************
*
*	TITLE:		autonomous.c
*
*	VERSION:	0.1 (Beta)
*
*	DATE:		31-Dec-2007
*
*	AUTHOR:		R. Kevin Watson
*				kevinw@jpl.nasa.gov
*
*	COMMENTS:	This file best viewed with tabs set to four.
*
*				You are free to use this source code for any non-commercial
*				use. Please do not make copies of this source code, modified
*				or un-modified, publicly available on the internet or elsewhere
*				without permission. Thanks.
*
*				Copyright �2007-2008 R. Kevin Watson. All rights are reserved.
*
********************************************************************************
*
*	Change log:
*
*	DATE         REV  DESCRIPTION
*	-----------  ---  ----------------------------------------------------------
*	31-Dec-2007  0.1  RKW Original
*
*******************************************************************************/
#include "ifi_frc.h"
#include "timers.h"
#include "interrupts.h"
#include "encoder.h"
#include "serial_ports.h"
#include "ifi_code.h"
#include "autonomous.h"
#include "camera.h"
#include "tracking.h"
#include "mort_defines.h"
#include "adc.h"

int Get_Auto_Mode(void)
{
    return CIRCLE_FIELD;
}

void Autonomous_Init(void)
{
    Initialize_Timer_2();
}

void Autonomous(void)
{
    Camera_Handler();

    switch(Get_Auto_Mode())
    {
        case CIRCLE_FIELD:
        {
            Circle_Field();

            break;
        }
        default:
        {
            Reset_Outputs();

            break;
        }
    }


}

void Autonomous_Spin(void)
{

}

void Robocoach_Override(void)
{
    static int timeflag1;
    static int timeflag2;
    static int timeflag3;

    if(timeflag1 < 112 )  //loops = number of seconds * milliseconds of processor (possibly 22.5)
    {
        Reset_Outputs();
        ++timeflag1;
    }
    else if(ROBOCOACH_1==1)
    {
        Reset_Outputs();
        timeflag1 = 0;
    }
    else if (ROBOCOACH_2)
    {
        Delay(100);
    }
    else if (ROBOCOACH_3)
    {

    }
    else if (ROBOCOACH_4)
    {

    }
}

void Delay(unsigned int ms)
{
    Timer_2_Reset();
    Timer_2_Start();
//  while ((ms == 0 || Timer_2_Get_Time() <= ms) && !ROBOCOACH_2)
    while (Timer_2_Get_Time() <= ms)
    {
        Getdata(&rxdata);
        if (statusflag.NEW_SPI_DATA)
        {
            Reset_Outputs();
            statusflag.NEW_SPI_DATA = 0;
        }
        Putdata(&txdata);
    }
    Timer_2_Stop();
}

void Circle_Field( void )
{
    static unsigned char auto_state = CIRCLE_FIELD_FOLLOW_WALL;
    static unsigned int counter = 0;
    unsigned int range_front = 0;
    unsigned int range_back = 0;
    int range_error_front = 0;
    int range_error_back = 0;
    int range_error_average = 0;
    int range_error_difference = 0;
    unsigned char range_aligned = 0;
    int x = 0;
    int y = 0;
    int z = 0;

    range_front = Get_ADC_Result(IR_LEFT_FRONT);
    range_back = Get_ADC_Result(IR_LEFT_BACK);
    range_error_front = CIRCLE_FIELD_DISTANCE_HUG - range_front;
    range_error_back = CIRCLE_FIELD_DISTANCE_HUG - range_back;
    range_error_average = (range_error_back + range_error_front)/2;
    range_error_difference = range_error_front - range_error_back;

    printf("State: %d  Front: %4d Back: %4d Diff: %4d\r\n", auto_state, range_front, range_back, range_error_difference);

    Service_Brakes(1);

    switch (auto_state)
    {
        case CIRCLE_FIELD_FOLLOW_WALL:


            y = CIRCLE_FIELD_FORWARD_SPEED;
            x = (range_error_average / 3)
            z = (range_error_difference / 3) * -1;

            if (range_front < CIRCLE_FIELD_DISTANCE_NOWALL)
            {
                y = CIRCLE_FIELD_FORWARD_SPEED;
                x =
                z = -20;
            }

            if (range_back < CIRCLE_FIELD_DISTANCE_NOWALL)
            {
                counter = 0;
                auto_state = CIRCLE_FIELD_TURN_LEFT;
            }

            break;


        case CIRCLE_FIELD_TURN_LEFT:

            counter++;

            y = CIRCLE_FIELD_FORWARD_SPEED;
            z = -20;

            if (counter >= 100)
            {
                z = 0;
            }

            if (counter >= 170)
            {
                auto_state = CIRCLE_FIELD_FOLLOW_WALL;
            }


            break;

    }
/*
    switch (auto_state)
    {
        case CIRCLE_FIELD_FIND_WALL:

            y = CIRCLE_FIELD_FORWARD_SPEED;

            if (range_front > CIRCLE_FIELD_DISTANCE_NOWALL && range_back > CIRCLE_FIELD_DISTANCE_NOWALL)
            {
                auto_state = CIRCLE_FIELD_FOLLOW_WALL;
            }

            break;

        case CIRCLE_FIELD_GET_TO_WALL:

            y = CIRCLE_FIELD_FORWARD_SPEED;

            if (range_error_average < (-1 * CIRCLE_FIELD_DISTANCE_DEADZONE) || range_error_average > CIRCLE_FIELD_DISTANCE_DEADZONE)
            {
                z = range_error_average * CIRCLE_FIELD_Z_GAIN;
            }
            else
            {
                z = 0;
            }

             break;

        case CIRCLE_FIELD_FOLLOW_WALL:

            y = CIRCLE_FIELD_FORWARD_SPEED;

            if (range_error_back < (-1 * CIRCLE_FIELD_DISTANCE_DEADZONE) || range_error_front > CIRCLE_FIELD_DISTANCE_DEADZONE)
            {
                z = range_error_back * CIRCLE_FIELD_Z_GAIN;
            }
            else
            {
                z = 0;
                range_aligned += 1;
            }

            if (range_error_front < (-1 * CIRCLE_FIELD_DISTANCE_DEADZONE) || range_error_front > CIRCLE_FIELD_DISTANCE_DEADZONE)
            {
                z = range_error_front * CIRCLE_FIELD_Z_GAIN;
            }
            else
            {
                z = 0;
                range_aligned += 1;
            }

            if (range_error_average < (-1 * CIRCLE_FIELD_DISTANCE_DEADZONE) || range_error_average > CIRCLE_FIELD_DISTANCE_DEADZONE);
            {
                auto_state = CIRCLE_FIELD_GET_TO_WALL;
            }

            if (range_aligned == 3)
            {
                auto_state = CIRCLE_FIELD_TURN_LEFT;
            }

            break;

        case CIRCLE_FIELD_TURN_LEFT:

            break;

    }

    */

    Mec_Drive_2(x, y, z);
}
