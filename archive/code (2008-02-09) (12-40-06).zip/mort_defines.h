/************************************************************************************
* FILE NAME: MORT_DEFINES.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2005 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
************************************************************************************/

#ifndef _MORT_DEFINES_H
#define _MORT_DEFINES_H_

/************************************************************************************
			                        MORT DEFINES
*************************************************************************************/

/**********************************CODE SWITCH DEFINES*******************************/
#define DEBUG_ROBOT

/*******************************USER CONTROL DEFINES*********************************/

#define DRIVE_X         p1_x
#define DRIVE_Y         p1_y
#define DRIVE_Z         p1_wheel
#define DRIVE_TRIG      p1_sw_trig

#define TOWER_JOYSTICK          p4_y
#define TOWER_BUTTON_ROLLERS    p4_sw_top
#define TOWER_BUTTON_LOW        p4_sw_aux1
#define TOWER_BUTTON_MIDDLE     p4_sw_top
#define TOWER_BUTTON_HIGH       p4_sw_trig

/************************************PWM DEFINES*************************************/
#define FRONT_LEFT      pwm01
#define FRONT_RIGHT     pwm02
#define BACK_LEFT       pwm03
#define BACK_RIGHT      pwm04

#define ROLLER_MOTOR    pwm06
#define TOWER_MOTOR     pwm07

/**********************************CONSTANT DEFINES**********************************/

#define HEIGHT_FLAG_HIGH        0
#define HEIGHT_FLAG_MIDDLE      1
#define HEIGHT_FLAG_LOW         2
#define HEIGHT_FLAG_MANUAL      3

#define HEIGHT_COUNT_HIGH       0
#define HEIGHT_COUNT_MIDDLE     0
#define HEIGHT_COUNT_LOW        0

#define TOWER_SPEED_UP_MAX      127
#define TOWER_SPEED_UP_MIN      127

#define TOWER_SPEED_DOWN_MAX    127
#define TOWER_SPEED_DOWN_MIN    127

#define TOWER_ENCODER_LIMIT     0
#define TOWER_JOY_DEADZONE      0
#define TOWER_ENCODER_DEADZONE  0

// Scaling constants
#define DRIVE_X_MAX             255
#define DRIVE_X_MIN             0
#define DRIVE_Y_MAX             255
#define DRIVE_Y_MIN             0
#define DRIVE_Z_MAX             255
#define DRIVE_Z_MIN             0
#define TOWER_JOYSTICK_MAX      255
#define TOWER_JOYSTICK_MIN      0

#define DRIVE_X_DEADBAND        0
#define DRIVE_Y_DEADBAND        0
#define DRIVE_Z_DEADBAND        0
#define TOWER_JOYSTICK_DEADBAND 0

/**********************************SENSOR DEFINES*************************************/
#define ROBOCOACH_1     rc_dig_in10
#define ROBOCOACH_2     rc_dig_in11
#define ROBOCOACH_3     rc_dig_in12
#define ROBOCOACH_4     rc_dig_in13

#define TOWER_OP_DOWN   rc_dig_in03

#define IR_LEFT_FRONT   13
#define IR_LEFT_BACK    14
#define IR_RIGHT_FRONT  15
#define IR_RIGHT_BACK   16

/***********************************OI FEEDBACK***************************************/
#define HEIGHT_LED_HIGH     Relay_2_green
#define HEIGHT_LED_MIDDLE   Relay_1_green
#define HEIGHT_LED_LOW      Relay_1_red

/********************************** CASE DEFINES *************************************/

/************************************ EXTERNS ****************************************/
extern unsigned char height_flag;
extern unsigned char tower_at_target;

/*******************************FUNCTION PROTOTYPES***********************************/

// Based on the code from ChiefDelphi, rounds off imidiatly, use comparison of mec(1,127,1) to mec(0,127,0) to see
void Mec_Drive_1(int, int, int);
// Writen based upon the white paper on CheifDephi, no rounding until the final assignment
void Mec_Drive_2(int, int, int);
// Both of these are utilized by Mec_Drive_2()
int abs(int);
int absmax(int,int);

int Limit (int, int, int);
int Deadband(int, int);
void Service_Joysticks(void);
void Service_Tower(int);
void Service_Height_Flags(void);

#endif
