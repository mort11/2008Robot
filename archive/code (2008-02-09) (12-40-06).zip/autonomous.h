/*******************************************************************************
* FILE NAME: autonomous.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2008 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
*******************************************************************************/

#ifndef _autonomous_h
#define _autonomous_h

// Defines for different autonomous modes
#define CIRCLE_FIELD    1


// Define the states for CIRCLE_FIELD
#define CIRCLE_FIELD_FIND_WALL_STRAIGHT
#define CIRCLE_FIELD_FIND_WALL_LEFT
#define CIRCLE_FIELD_DRIVE_STRAIGHT 1
#define CIRCLE_FIELD_STRAFE_LEFT    2
#define CIRCLE_FIELD_DRIVE_BACK     3
#define CIRCLE_FIELD_STRAFE_RIGHT   4


// function prototypes
void Autonomous_Init(void);
void Autonomous(void);
void Autonomous_Spin(void);

// Mort Functions
int Get_Auto_Mode(void);
void MORT_Autonomous_Mode(int mode);
void Delay(unsigned int);
void Robocoach_Override(void);
void Circle_Field( void );
#endif
