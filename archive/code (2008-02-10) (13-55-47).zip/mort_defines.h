/************************************************************************************
* FILE NAME: MORT_DEFINES.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2005 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
************************************************************************************/

#ifndef _MORT_DEFINES_H
#define _MORT_DEFINES_H_

/************************************************************************************
			                        MORT DEFINES
*************************************************************************************/

/**********************************CODE SWITCH DEFINES*******************************/
#define DEBUG_ROBOT

#define ON      1
#define OFF     0

/*******************************USER CONTROL DEFINES*********************************/

#define DRIVE_X         p1_x
#define DRIVE_Y         p1_y
#define DRIVE_Z         p1_wheel
#define DRIVE_TRIG      p1_sw_trig

/* TODO (MORT#1#): Tower joystick is wrong */
#define TOWER_JOYSTICK          p3_y
#define TOWER_BUTTON_ROLLERS    p3_sw_top
#define TOWER_BUTTON_LOW        p4_sw_aux1
#define TOWER_BUTTON_MIDDLE     p4_sw_top
#define TOWER_BUTTON_HIGH       p4_sw_trig

/************************************PWM DEFINES*************************************/
#define FRONT_LEFT      pwm03
#define FRONT_RIGHT     pwm04
#define BACK_LEFT       pwm02
#define BACK_RIGHT      pwm01

#define ROLLER_MOTOR    pwm06
#define TOWER_MOTOR     pwm07

/**********************************CONSTANT DEFINES**********************************/

#define HEIGHT_FLAG_HIGH        3
#define HEIGHT_FLAG_MIDDLE      2
#define HEIGHT_FLAG_LOW         1
#define HEIGHT_FLAG_MANUAL      0

#define HEIGHT_COUNT_HIGH       10
#define HEIGHT_COUNT_MIDDLE     20
#define HEIGHT_COUNT_LOW        30

#define TOWER_SPEED_UP_MAX      127
#define TOWER_SPEED_UP_MIN      127

#define TOWER_SPEED_DOWN_MAX    127
#define TOWER_SPEED_DOWN_MIN    127

#define TOWER_ENCODER_LIMIT     100
#define TOWER_ENCODER_DEADZONE  1

// Scaling constants
#define DRIVE_X_MAX             130         // Joystick left
#define DRIVE_X_OFFSET          92
#define DRIVE_X_MIN             (-1 * 69)   // Joystick right

#define DRIVE_Y_MAX             117         // Joystick up
#define DRIVE_Y_OFFSET          88
#define DRIVE_Y_MIN             (-1 * 67)   // Joystick down

#define DRIVE_Z_MAX             107         // Joystick twist left
#define DRIVE_Z_OFFSET          68
#define DRIVE_Z_MIN             (-1 * 68)   // Joystick twist right

#define TOWER_JOYSTICK_MAX      57
#define TOWER_JOYSTICK_OFFSET   49
#define TOWER_JOYSTICK_MIN      (-1 * 47)      // Pushed forward

#define DRIVE_X_DEADBAND        15
#define DRIVE_Y_DEADBAND        15
#define DRIVE_Z_DEADBAND        25
#define TOWER_JOYSTICK_DEADBAND 10

#define PWM_DEADZONE_LEFT       12.0
#define PWM_DEADZONE_RIGHT      12.0

/**********************************SENSOR DEFINES*************************************/
#define ROBOCOACH_1     rc_dig_in10
#define ROBOCOACH_2     rc_dig_in11
#define ROBOCOACH_3     rc_dig_in12
#define ROBOCOACH_4     rc_dig_in13

#define BREAK_1         rc_dig_out03
#define BREAK_2         rc_dig_out04
#define BREAK_3         rc_dig_out05
#define BREAK_4         rc_dig_out06

#define TOWER_OP_DOWN   rc_dig_in03

#define IR_LEFT_FRONT   13
#define IR_LEFT_BACK    14
#define IR_RIGHT_FRONT  15
#define IR_RIGHT_BACK   16

#define PROGRAM_BUTTON  rc_dig_in18

/***********************************OI FEEDBACK***************************************/
#define HEIGHT_LED_HIGH     Relay2_green
#define HEIGHT_LED_MIDDLE   Relay1_green
#define HEIGHT_LED_LOW      Relay1_red

/********************************** CASE DEFINES *************************************/

/************************************ EXTERNS ****************************************/
extern unsigned char height_flag;
extern unsigned char tower_at_target;

/*******************************FUNCTION PROTOTYPES***********************************/

// Based on the code from ChiefDelphi, rounds off imidiatly, use comparison of mec(1,127,1) to mec(0,127,0) to see
void Mec_Drive_1(int, int, int);
// Writen based upon the white paper on CheifDephi, no rounding until the final assignment
void Mec_Drive_2(int, int, int);
// Both of these are utilized by Mec_Drive_2()
int abs(int);
int absmax(int,int);

int Limit (int, int, int);
int Deadband(int, int);
void Service_Joysticks(void);
void Service_Tower(void);
void Service_Height_Flags(void);
void Service_Height_Flags_2(void);
void Service_Brakes(unsigned char);
void Service_Leds(void);
void Service_Program_Button(void);

#endif
