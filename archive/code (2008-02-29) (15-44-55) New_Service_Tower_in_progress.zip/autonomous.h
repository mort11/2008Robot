/*******************************************************************************
* FILE NAME: autonomous.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2008 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
*******************************************************************************/

#ifndef _autonomous_h
#define _autonomous_h

void Autonomous_Init(void);
void Autonomous(void);
void Autonomous_Spin(void);

int Get_Auto_Mode(void);

void IR_Drive(void);

#endif
