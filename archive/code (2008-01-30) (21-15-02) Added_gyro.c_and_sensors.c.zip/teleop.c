/*******************************************************************************
*
*	TITLE:		teleop.c
*
*	VERSION:	0.1 (Beta)
*
*	DATE:		31-Dec-2007
*
*	AUTHOR:		R. Kevin Watson
*				kevinw@jpl.nasa.gov
*
*	COMMENTS:	This file best viewed with tabs set to four.
*
*				You are free to use this source code for any non-commercial
*				use. Please do not make copies of this source code, modified
*				or un-modified, publicly available on the internet or elsewhere
*				without permission. Thanks.
*
*				Copyright �2007-2008 R. Kevin Watson. All rights are reserved.
*
********************************************************************************
*
*	Change log:
*
*	DATE         REV  DESCRIPTION
*	-----------  ---  ----------------------------------------------------------
*	31-Dec-2007  0.1  RKW Original
*
*******************************************************************************/

#include <adc.h>
#include "ifi_frc.h"
#include "pwm.h"
#include "timers.h"
#include "interrupts.h"
#include "encoder.h"
#include "serial_ports.h"
#include "ifi_code.h"
#include "teleop.h"
#include "camera.h"
#include "tracking.h"
#include "mort_defines.h"
#include "sensors.h"
#include "gyro.h"

/*******************************************************************************
*
*	FUNCTION:		Teleop_Init()
*
*	PURPOSE:		This is where you put code that needs to execute
*					just once at the start of teleoperation mode.
*
*	CALLED FROM:	main() in ifi_frc.c
*
*	PARAMETERS:		None
*
*	RETURNS:		Nothing
*
*	COMMENTS:		While in this mode, all operator interface data is valid
*					and all robot controller outputs are enabled.
*
*******************************************************************************/
void Teleop_Init(void)
{

}

/*******************************************************************************
*
*	FUNCTION:		Teleop()
*
*	PURPOSE:		This is where you put code that you want to execute while
*					your robot is in teleoperation mode. While in teleoperation
*					mode, this function is called every	26.2ms after new data
*					is received from the master processor.
*
*	CALLED FROM:	main() in ifi_frc.c
*
*	PARAMETERS:		None
*
*	RETURNS:		Nothing
*
*	COMMENTS:		While in this mode, all operator interface data is valid
*					and all robot controller outputs are enabled.
*
*******************************************************************************/
void Teleop(void)
{

    Chip_Diag();

    //IR_Diag();

    //printf("%d, ", rc_dig_in01);

	//long Encoder_Count;

   // Encoder_Count = Get_Encoder_1_Count();
   // printf("E1=%d\r\n",(int)Encoder_Count);

    //printf("x: %d y: %d z: %d trigger:%d \r\n", p1_aux, p1_y, p1_wheel, p1_sw_trig);

}

/*******************************************************************************
*
*	FUNCTION:		Teleop_Spin()
*
*	PURPOSE:		While in teleoperation mode, this function is called
*					continuously between calls to Teleop().
*
*	CALLED FROM:	main() in ifi_frc.c
*
*	PARAMETERS:		None
*
*	RETURNS:		Nothing
*
*	COMMENTS:		While in this mode, all operator interface data is valid
*					and all robot controller outputs are enabled.
*
*******************************************************************************/
void Teleop_Spin(void)
{
    Process_Gyro_Data();
}

void Mec_Drive_1(int x, int y, int z)
{
	int left_front, left_back, right_front, right_back;

    //Round up to the nearest integer
	int reduction_factor = (x && 1) + (y && 1) + (z && 1);

	if (!reduction_factor)
	{
	    left_front = 0;
	    left_back = 0;
	    right_front = 0;
	    right_back = 0;
	}
	else
	{
		int left_back_x, left_back_z;
		int right_front_x, right_front_z;
		int right_back_x, right_back_z;

	    x = x / reduction_factor;
		z = z / reduction_factor;
		y = y / reduction_factor;

		right_back_x = -x;
		right_front_x = x;
		left_back_x = right_front_x;

		right_back_z = -z;
		right_front_z = right_back_z;
		left_back_z = z;

		left_front 	= 	-x + y + z;
		left_back 	= 	left_back_x  + 	y + left_back_z;
		right_front =	right_front_x + y + right_front_z;
		right_back 	= 	right_back_x + 	y + right_back_z;
	}

	// Make the value range from 0 to 255, with 128 and 127 of the converted value being equal
	left_front 	+= 127 + (left_front 	> 0);
	left_back 	+= 127 + (left_back 	> 0);
	right_front += 127 + (right_front 	> 0);
	right_back 	+= 127 + (right_back 	> 0);

	// CHANGE TO DEFINES FOR PWMS
	FRONT_LEFT 	= left_front;
	FRONT_RIGHT = right_front;
	BACK_LEFT 	= left_back;
	BACK_RIGHT 	= right_back;
}

void Mec_Drive_2(int x, int y, int z)
{
	int left_front;
	int left_back;
	int right_front;
	int right_back;
    double reduction;

	right_front=y-x+z;
	left_front=y+x-z;
	right_back=y+x+z;
	left_back=y-x-z;

    // Using the reduction variable here to avoid movre variables.
    // Finds the absolute maximum value of the 4 wheel speeds
	reduction = absmax( absmax(right_front,right_back) , absmax(left_front, left_back) );

	// Determine the multiple to decrease the motor values by
	if (reduction > 127.0)
	{
		reduction /= 127.0;
	}
	else if (reduction < -127.0)
	{
	    //
		reduction /= -127.0;
	}
	else
	{
	    // If we are within the range, no reduction
		reduction = 1;
	}

    //Reduce the motor values so that the max is at 127 or min at -127
	left_front /= reduction;
	left_back /= reduction;
	right_back /= reduction;
	right_front /= reduction;

    // Make the value range from 0 to 255, with 128 and 127 of the converted value being equal
	left_front 	+= 128 + (left_front 	> 0);
	left_back 	+= 128 + (left_back 	> 0);
	right_front += 128 + (right_front 	> 0);
	right_back 	+= 128 + (right_back 	> 0);

	// CHANGE TO DEFINES FOR PWMS
	FRONT_LEFT 	= left_front;
	FRONT_RIGHT = right_front;
	BACK_LEFT 	= left_back;
	BACK_RIGHT 	= right_back;
}

int absmax(int n1,int n2)
{
	if(abs(n1) > abs(n2))
		return n1;
	else
		return n2;

}

int abs(int n)
{
	if (n < 0)
		return -n;
	else
		return  n;
}

int Limit (int num, int low, int high)
{
	if (num > high)
		num = high;
	else if (num < low)
		num = low;

	return num;
}


char Deadband(int value, int band)
{
	if (value <= (band/2.0) && value >= (-band/2.0))
	{
		return 0;
	}
	else if (value > 0)
	{
		return (127* (value - band/2.0) /(127 - band/2.0));
	}
	else
	{
		return (127* (value + band/2.0) /(127 - band/2.0));
	}
}

void Service_Arm (int height)
{
	int encoder_count = 0;
	int encoder_error = 0;
	int y = 0;

	encoder_count = Get_Encoder_1_Count();

	if (height >= 0)
	{
		encoder_error = height - encoder_count;
		y = encoder_error * ARM_GAIN;
	}
	else
	{
		y = ARM_JOYSTICK;
	}

	Limit(y, -127, 127);

	ARM_MOTOR = y + 127;
}

void Service_Rollers(int speed)
{
    int y = 0;

	if (ARM_BUTTON)
	{
		y = ARM_JOYSTICK;
	}
	else
	{
		y = speed;
	}

	Limit(y, -127, 127);

	ROLLER_MOTOR = y + 127;
}
