/************************************************************************************
* FILE NAME: MORT_DEFINES.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2005 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
************************************************************************************/

#ifndef _MORT_DEFINES_H
#define _MORT_DEFINES_H_

/************************************************************************************
			                        MORT DEFINES
*************************************************************************************/

/**********************************CODE SWITCH DEFINES*******************************/
#define DEBUG_ROBOT

/*******************************USER CONTROL DEFINES*********************************/

#define DRIVE_X         p1_aux
#define DRIVE_Y         p1_y
#define DRIVE_Z         p1_wheel

#define ARM_JOYSTICK    p2_y
#define ARM_BUTTON      p2_sw_trig

/************************************PWM DEFINES*************************************/
// Moved to outputs.h

/**********************************CONSTANT DEFINES**********************************/

#define MANUAL          -1

#define RIGHT 		    1
#define LEFT 		    -1

#define X_GAIN 		    1
#define	Y_GAIN 		    1
#define ARM_GAIN        1

#define SEARCH_SPEED    30

/**********************************SENSOR DEFINES*************************************/
// Moved to sensors.h

/***********************************OI FEEDBACK***************************************/


/********************************** CASE DEFINES**************************************/

/*******************************FUNCTION PROTOTYPES***********************************/
// Many moved to outputs.h

void Track_Ball(void);
#endif
