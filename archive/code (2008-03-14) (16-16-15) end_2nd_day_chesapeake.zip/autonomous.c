/*******************************************************************************
*
*	TITLE:		autonomous.c
*
*	VERSION:	0.1 (Beta)
*
*	DATE:		31-Dec-2007
*
*	ATHOR:		R. Kevin Watson
*				kevinw@jpl.nasa.gov
*
*	COMMENTS:	This file best viewed with tabs set to four.
*
*				You are free to use this source code for any non-commercial
*				use. Please do not make copies of this source code, modified
*				or un-modified, publicly available on the internet or elsewhere
*				without permission. Thanks.
*
*				Copyright �2007-2008 R. Kevin Watson. All rights are reserved.
*
********************************************************************************
*
*	Change log:
*
*	DATE         REV  DESCRIPTION
*	-----------  ---  ----------------------------------------------------------
*	31-Dec-2007  0.1  RKW Original
*
*******************************************************************************/
#include "ifi_frc.h"
#include "timers.h"
#include "interrupts.h"
#include "encoder.h"
#include "serial_ports.h"
#include "ifi_code.h"
#include "autonomous.h"
#include "mort_defines.h"
#include "adc.h"
#include "gyro.h"

int x = 0;
int y = 0;
int z = 0;

int mode;

long angle = 0;

extern unsigned char height_flag;

unsigned char auto_state = 0;

int Get_Auto_Mode(void)
{
    if (rc_dig_in10 == 0)        // red 1
        return 1;
    else if (rc_dig_in11 == 0)   // red 2
        return 2;
    else if (rc_dig_in12 == 0)   // blue 1
        return 3;
    else if (rc_dig_in13 == 0)   // blue 2
        return 4;
    else
        return -1;
}

void Autonomous_Init(void)
{
    height_flag = HEIGHT_FLAG_MANUAL;
    Timer_2_Start();
    mode = Get_Auto_Mode();

    Stop_Gyro_Bias_Calc();
    Reset_Gyro_Angle();
}

void Autonomous(void)
{
    Service_Brakes(1);

    if (mode == 1) // red 1
        IR_Drive();
    else if (mode == 2) // red 2
        Drive_Straight();
        //Track_Ball();
    else if (mode == 3) // blue 1
//        Drive_Continuous();
        IR_Drive2();
    else if (mode == 4) // blue 2
        Drive_Straight_Gyro();
    else
        Reset_Outputs();

    Service_Tower();
    Mec_Drive(x,y,z);
    Service_Dashboard_Data();
}

void Autonomous_Spin(void)
{
    Process_Gyro_Data(TRUE);
    angle = Get_Gyro_Angle();
}

void Drive_Straight()
{
    /*
    if (Timer_2_Get_Time() < 2000)
    {
        x= 0;
        y= 0;
        z= 0;
    }
    else*/

    if ((ROBOCOACH_1 || ROBOCOACH_2 || ROBOCOACH_3 || ROBOCOACH_4) && Timer_2_Get_Time() > 2500)
    {
        mode = 1;
    }
    else if (Timer_2_Get_Time() < 4000) // 5800
    {
        x= 0;
        y= -127;
        z= 5;
    }
    else
    {
        mode = 1;
        Timer_2_Reset();
    }
}

void IR_Drive(void)
{
//    static int tower_flag;

    printf("%d  %d  %d  %d \r\n",ROBOCOACH_1,ROBOCOACH_2,ROBOCOACH_3,ROBOCOACH_4);
//    height_flag= HEIGHT_FLAG_MIDDLE;

    if(ROBOCOACH_1)
    {
        x=0;
        y=0;
        z=70;
        Timer_2_Reset();
        printf("1\r\n");
    }
    else if (ROBOCOACH_2)
    {
        x=0;
        y=-127;
        z=0;
        Timer_2_Reset();
//        height_flag= HEIGHT_FLAG_MIDDLE;

        printf("2\r\n");
    }
    else if (ROBOCOACH_3)
    {
        x=0;
        y=0;
        z=-70;
        Timer_2_Reset();
        printf("3\r\n");
    }
    else if (ROBOCOACH_4)
    {
        x= 0;
        y= 127;
        z= 0;
        Timer_2_Reset();
        printf("4\r\n");
    }
    else if (Timer_2_Get_Time() >= 125)
    {
        x=0;
        y=0;
        z=0;
//        height_flag= HEIGHT_FLAG_LOW;

        printf("5\r\n");
    }
}

void IR_Drive2(void)
{
    int angle_error;

    printf("%d  %d  %d  %d \r\n",ROBOCOACH_1,ROBOCOACH_2,ROBOCOACH_3,ROBOCOACH_4);

    angle_error = angle - IR_ANGLE * ANGLE_GAIN;
//        height_flag= HEIGHT_FLAG_MIDDLE;

    if(ROBOCOACH_1)
    {
        x=0;
        y=0;

        if(angle_error > 2  || angle_error < -2)
        {
            z = -127;
        }
        else
        {
            z = 0;
            Reset_Gyro_Angle();
        }
        Timer_2_Reset();
    }
    else if (ROBOCOACH_2)
    {
        x=0;
        y=127;
        z=0;
        Timer_2_Reset();
        Reset_Gyro_Angle();
    }
    else if (ROBOCOACH_3)
    {
        x=0;
        y=0;

        if(angle_error > 2  || angle_error < -2)
        {
            z = 127;
        }
        else
        {
            z = 0;
            Reset_Gyro_Angle();
        }

        Timer_2_Reset();
    }
    else if (ROBOCOACH_4)
    {
        x= 0;
        y= -127;
        z= 0;
        Reset_Gyro_Angle();
    }
    else if (Timer_2_Get_Time() >= 125)
    {
        x=0;
        y=0;
        z=0;
        Reset_Gyro_Angle();
    }
}

void Drive_Straight_Gyro()
{
    if ((ROBOCOACH_1 || ROBOCOACH_2 || ROBOCOACH_3 || ROBOCOACH_4) && Timer_2_Get_Time() > 2500)
    {
        mode = 1;
    }
    else if (Timer_2_Get_Time() < 3500) // 5800
    {
        x= 0;
        y= -127;
        z= Get_Gyro_Angle() / 8 ;
    }
    else
    {
        mode = 1;
        Timer_2_Reset();
    }
}

void Drive_Continuous()
{
    static unsigned char auto_state = DRIVE_FORWARD;
    static unsigned char state_count = 0;
    switch (auto_state)
    {
        case DRIVE_FORWARD:
            z = 0;
            x= 0;
            y = -127;
            if (Timer_2_Get_Time() > 3800)
            {
                auto_state = TURN_1;
                state_count++;
            }
            break;
        case TURN_1:
            x= 0;
            y = -CIRCLE_FIELD_FORWARD_SPEED;
            z = CIRCLE_FIELD_TURN_LEFT_SPEED;
            if(angle < -510)
            {
                state_count++;
                auto_state= TURN_FORWARD;
                Reset_Gyro_Angle();
                Timer_2_Reset();
            }
            break;
        case TURN_FORWARD:
            x=0;
            y=-127;
            z= 0;
            if (Timer_2_Get_Time() < 700)
            {
                state_count ++;
                auto_state = TURN_2;
            }
            break;
        case TURN_2:
            x= 0;
            y = CIRCLE_FIELD_FORWARD_SPEED;
            z = CIRCLE_FIELD_TURN_LEFT_SPEED;
            if (angle < -510)
            {
                state_count ++;
                auto_state = DRIVE_FORWARD;
                Reset_Gyro_Angle();
                Timer_2_Reset();
            }
            break;
    }
}

/*
else if(ROBOCOACH_4)
{
    if (( height_flag == HEIGHT_FLAG_MANUAL || height_flag == HEIGHT_FLAG_LOW) && Get_Encoder_1_Count() == 0)
    {
        height_flag = HEIGHT_FLAG_MIDDLE;
    }
    else
    {
        height_flag = HEIGHT_FLAG_LOW;
    }
    Timer_2_Reset();
}

*/

/*
else if (ROBOCOACH_4 && Timer_2_Get_Time() > 100)
{
    if (tower_flag == 1)
    {
        height_flag = HEIGHT_FLAG_LOW;
        tower_flag = 0;
    }
    else if (tower_flag == 0)
    {
        height_flag = HEIGHT_FLAG_MIDDLE;
        tower_flag = 1;
    }
    Timer_2_Reset();
}
*/
