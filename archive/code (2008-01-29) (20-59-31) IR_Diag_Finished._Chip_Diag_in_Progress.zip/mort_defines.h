/************************************************************************************
* FILE NAME: MORT_DEFINES.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2005 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
************************************************************************************/

#ifndef _MORT_DEFINES_H
#define _MORT_DEFINES_H_

/************************************************************************************
			                        MORT DEFINES
*************************************************************************************/

/*******************************USER CONTROL DEFINES*********************************/

#define DRIVE_X         p1_aux
#define DRIVE_Y         p1_y
#define DRIVE_Z         p1_wheel

#define ARM_JOYSTICK    p2_y
#define ARM_BUTTON      p2_sw_trig

/************************************PWM DEFINES*************************************/

#define FRONT_LEFT      pwm01
#define FRONT_RIGHT     pwm02
#define BACK_LEFT       pwm03
#define BACK_RIGHT      pwm04

#define ARM_MOTOR       pwm05
#define ROLLER_MOTOR    pwm06


/**********************************CONSTANT DEFINES**********************************/

#define MANUAL          -1

#define RIGHT 		    1
#define LEFT 		    -1

#define X_GAIN 		    1
#define	Y_GAIN 		    1
#define ARM_GAIN        1

#define SEARCH_SPEED    30

/**********************************SENSOR DEFINES*************************************/
#define ROBOCOACH_1     rc_dig_in10
#define ROBOCOACH_2     rc_dig_in11
#define ROBOCOACH_3     rc_dig_in12
#define ROBOCOACH_4     rc_dig_in13

#define IR_LIMIT        rc_dig_in01
#define IR_FRONT        rc_ana_in10
#define IR_SIDE         rc_ana_in11

#define GYRO
#define ACCEL

#define CHIP_1_A        rc_ana_in01
#define CHIP_1_B        rc_ana_in02
#define CHIP_2_A        rc_ana_in03
#define CHIP_2_B        rc_ana_in04

/***********************************OI FEEDBACK***************************************/


/********************************** CASE DEFINES**************************************/

/*******************************FUNCTION PROTOTYPES***********************************/

// Based on the code from ChiefDelphi, rounds off imidiatly, use comparison of mec(1,127,1) to mec(0,127,0) to see
void Mec_Drive_1(int, int, int);

// Writen based upon the white paper on CheifDephi, no rounding until the final assignment
void Mec_Drive_2(int, int, int);

// Both of these are utilized by Mec_Drive_2()
int abs(int);
int absmax(int,int);

int Limit (int, int, int);
char Deadband(int, int);
void Service_Arm(int);
void Service_Rollers(int);
void Track_Ball(void);
#endif
