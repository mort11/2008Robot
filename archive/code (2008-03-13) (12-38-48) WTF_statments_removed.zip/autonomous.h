/*******************************************************************************
* FILE NAME: autonomous.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2008 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
*******************************************************************************/

#ifndef _autonomous_h
#define _autonomous_h

#define CIRCLE_FIELD_FORWARD_SPEED          40
#define CIRCLE_FIELD_DISTANCE_HUG           1000   // increases as it gets closer
#define CIRCLE_FIELD_DISTANCE_NOWALL        50
#define CIRCLE_FIELD_Z_GAIN                 7.0
#define CIRCLE_FIELD_Z_LIMIT                20
#define CIRCLE_FIELD_TURN_LEFT_SPEED        (-1*40)

#define DRIVE_FORWARD 1
#define TURN_FORWARD 2
#define TURN_1 3
#define TURN_2 4

void Autonomous_Init(void);
void Autonomous(void);
void Autonomous_Spin(void);
void Drive_Straight(void);
void Drive_Continuous(void);
int Get_Auto_Mode(void);

void IR_Drive(void);

#endif
