// Functions of sensors.c
// Handle the input of data from various sensors on the RC
#ifndef _sensors_h
#define _sensors_h

/** Defines **/
#define ROBOCOACH_1     rc_dig_in10
#define ROBOCOACH_2     rc_dig_in11
#define ROBOCOACH_3     rc_dig_in12
#define ROBOCOACH_4     rc_dig_in13

#define IR_LIMIT        rc_dig_in01
#define IR_SIDE         rc_ana_in10
#define IR_FRONT        rc_ana_in11

#define GYRO_CHANNEL    rc_ana_in01
#define TEMP_CHANNEL    rc_ana_in02
#define ACCEL_X_CHANNEL rc_ana_in03
#define ACCEL_Y_CHANNEL rc_ana_in04

/** Functions **/
void Chip_Diag( void );
void IR_Diag( void );

#endif
