/*******************************************************************************
*
*	TITLE:		autonomous.c
*
*	VERSION:	0.1 (Beta)
*
*	DATE:		31-Dec-2007
*
*	AUTHOR:		R. Kevin Watson
*				kevinw@jpl.nasa.gov
*
*	COMMENTS:	This file best viewed with tabs set to four.
*
*				You are free to use this source code for any non-commercial
*				use. Please do not make copies of this source code, modified
*				or un-modified, publicly available on the internet or elsewhere
*				without permission. Thanks.
*
*				Copyright �2007-2008 R. Kevin Watson. All rights are reserved.
*
********************************************************************************
*
*	Change log:
*
*	DATE         REV  DESCRIPTION
*	-----------  ---  ----------------------------------------------------------
*	31-Dec-2007  0.1  RKW Original
*
*******************************************************************************/
#include "ifi_frc.h"
#include "timers.h"
#include "interrupts.h"
#include "encoder.h"
#include "serial_ports.h"
#include "ifi_code.h"
#include "autonomous.h"
#include "camera.h"
#include "tracking.h"
#include "mort_defines.h"

int Get_Auto_Mode(void)
{
    return CIRCLE_FIELD;
}

void Autonomous_Init(void)
{
    Initialize_Timer_2();
}

void Autonomous(void)
{
    Camera_Handler();

    switch(Get_Auto_Mode())
    {
        case CIRCLE_FIELD:
        {
            Circle_Field();

            break;
        }
        default:
        {
            Reset_Outputs();

            break;
        }
    }


}

void Autonomous_Spin(void)
{
}

void Robocoach_Override(void)
{
    static int timeflag1;
    static int timeflag2;
    static int timeflag3;

    if(timeflag1 < 112 )  //loops = number of seconds * milliseconds of processor (possibly 22.5)
    {
        Reset_Outputs();
        ++timeflag1;
    }
    else if(ROBOCOACH_1==1)
    {
        Reset_Outputs();
        timeflag1 = 0;
    }
    else if (ROBOCOACH_2)
    {
        Delay(100);
    }
    else if (ROBOCOACH_3)
    {

    }
    else if (ROBOCOACH_4)
    {

    }
}

void Delay(unsigned int ms)
{
    Timer_2_Reset();
    Timer_2_Start();
//  while ((ms == 0 || Timer_2_Get_Time() <= ms) && !ROBOCOACH_2)
    while (Timer_2_Get_Time() <= ms)
    {
        Getdata(&rxdata);
        if (statusflag.NEW_SPI_DATA)
        {
            Reset_Outputs();
            statusflag.NEW_SPI_DATA = 0;
        }
        Putdata(&txdata);
    }
    Timer_2_Stop();
}

void Circle_Field( void )
{
    static unsigned char auto_state = CIRCLE_FIELD_DRIVE_STRAIGHT;

    switch (auto_state)
    {
        case CIRCLE_FIELD_DRIVE_STRAIGHT:
        {
            unsigned char int range_front = 0;
            unsigned char int range_back = 0;
            unsigned char int range_average = 0;

            range_front = Get_ADC_Result(IR_LEFT_FRONT);
            range_back = Get_ADC_Result(IR_LEFT_BACK);

            range_average = (range_front + range_back) / 2;

            Mec_Drive_2(0,CIRCLE_FIELD_FORWARD_SPEED,0);

            break;
        }
    }
}
