/************************************************************************************
* FILE NAME: MORT_DEFINES.h
*
* DESCRIPTION:
*  This is the include file that defines all I/O used in the MORT 2005 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
************************************************************************************/

#ifndef _MORT_DEFINES_H
#define _MORT_DEFINES_H_

/************************************************************************************
			                        MORT DEFINES
*************************************************************************************/

/*******************************USER CONTROL DEFINES*********************************/


/************************************PWM DEFINES*************************************/

#define FRONT_LEFT  pwm01
#define FRONT_RIGHT pwm02

#define BACK_LEFT   pwm03
#define BACK_RIGHT  pwm04


/**********************************CONSTANT DEFINES**********************************/



/**********************************SENSOR DEFINES*************************************/


/***********************************OI FEEDBACK***************************************/


/********************************** CASE DEFINES**************************************/

/*******************************FUNCTION PROTOTYPES***********************************/
void Mec_Drive(int, int, int);
int Limit (int, int, int);
char Deadband(char, char);

#endif
