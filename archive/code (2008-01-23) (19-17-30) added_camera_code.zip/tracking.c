#include <stdio.h>
#include "mort_defines.h"
#include "tracking.h"
#include "camera.h"

void Track_Ball(void) //REMINDER FOR ALEX *** CAN ADD INTEGRAL TYPE FUNCTIONALITY WITH GYRO ON X AXIS LATER ***
{
	#define RIGHT 		 1
	#define LEFT 		 -1
	#define X_GAIN 		 1 //REMINDER FOR ALEX *** MAKE 1 X GAIN FOR LEFT ONE FOR RIGHT TO OFFSET SOME OF THE PROBLEMS WITH THE CAMERA AND HOW ITS CENTER IS OFF ***
	#define	Y_GAIN 		 1
	#define Z_GAIN       1
	#define SEARCH_SPEED 30

	int pan_error = 0;     //set all these to 0 normally until we calculate
	int tilt_error = 0;
	int x = 0;
	int y = 0;
	int z = 0;

	static signed char previous_direction = LEFT; //left because if you think about how the field is, it makes more sense. we start in corner
	static unsigned int old_camera_t_packets = 0;

	if(camera_t_packets != old_camera_t_packets) //if all is good with the camera
	{
		old_camera_t_packets = camera_t_packets; //update so we know next time if the camera is working


		if(T_Packet_Data.confidence >= CONFIDENCE_THRESHOLD_DEFAULT)
		{

			pan_error = (int)T_Packet_Data.mx - PAN_TARGET_PIXEL_DEFAULT;  //calculate errors
			tilt_error = (int)T_Packet_Data.my - TILT_TARGET_PIXEL_DEFAULT;

			z = 0; //only use turning below in the searching code so we set it to 0

			if(pan_error > PAN_ALLOWABLE_ERROR_DEFAULT) // need two if's because of previous direction
			{
				previous_direction = RIGHT; //we know it's going right
				x = pan_error * X_GAIN; //set x
			}
			else if (pan_error < -1 * PAN_ALLOWABLE_ERROR_DEFAULT)
			{
				previous_direction = LEFT; //we know it's going left
				x = pan_error * X_GAIN; // set x
			}
			else //on target
			{
				x = 0; //x is 0 if it's ligned up
			}

			if(tilt_error > TILT_ALLOWABLE_ERROR_DEFAULT || tilt_error < -1 * TILT_ALLOWABLE_ERROR_DEFAULT) //only need one if, no previous direction
			{
				y = tilt_error * Y_GAIN; //set y
			}
			else //on target
			{
				y = 0; // y is zero if it's ligned up
			}

		}
		else //cant see ball - searching
		{
			x = 0;
			y = 0;
			z = SEARCH_SPEED * previous_direction * Z_GAIN;

		}
	}
	else //if all is not well with the camera and we are F'D just turn everying off
	{
		x=0;
		y=0;
		z=0;
	}


	x = Limit(x, -127, 127); // check to see that nothing is overflowing
	y = Limit(y, -127, 127);
	z = Limit(z, -127, 127);

	Mec_Drive (x, y, z); // send everything to our motor function

}
